import sharp from 'sharp';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import fetch from 'node-fetch';

const client = new S3Client({
  region: process.env.S3_REGION,
  endpoint: process.env.S3_ENDPOINT,
  credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY },
});

export async function processPhoto(photo) {
  const res = await fetch(photo.original_url);
  const buf = Buffer.from(await res.arrayBuffer());

  let img = sharp(buf).rotate().normalize();
  const meta = await img.metadata();

  const svg = `<svg width="${meta.width}" height="${meta.height}">
    <text x="${(meta.width||1000)-20}" y="${(meta.height||1000)-20}" font-size="${Math.floor((meta.width||1000)/25)}"
      text-anchor="end" fill="white" opacity="0.8">FLARE</text></svg>`;

  const processed = await img
    .composite([{ input: Buffer.from(svg), left:0, top:0 }])
    .jpeg({ quality: 88 })
    .toBuffer();

  // Derive processed key location
  const parts = photo.original_url.split('/');
  const last3 = parts.slice(-3).join('/'); // events/<eventId>/<file>
  const key = last3.replace('events/', 'processed/');

  await client.send(new PutObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key, Body: processed, ContentType: 'image/jpeg' }));

  const publicUrl = `${process.env.S3_PUBLIC_BASE}/${key}`;
  await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/photos`, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ photoId: photo.id, editedUrl: publicUrl })});
}

console.log("Worker IA listo. Llámalo desde tu cola o función programada al detectar nuevas filas en 'photos'.");
