'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase-client';

export default function Gallery({ params }: { params: { eventId: string }}) {
  const { eventId } = params;
  const [photos, setPhotos] = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('photos')
        .select('*')
        .eq('event_id', eventId)
        .order('created_at', { ascending: false });
      setPhotos(data || []);
    };
    load();

    const channel = supabase
      .channel('photos-ch')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'photos', filter: `event_id=eq.${eventId}` }, () => {
        load();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [eventId]);

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <h1 className="text-2xl font-bold mb-4">Galería — Evento {eventId.slice(0,8)}…</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {photos.map((p) => (
          <div key={p.id} className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={p.edited_url || p.original_url} alt="photo" className="w-full h-full object-cover rounded"/>
            {p.status !== 'processed' && (
              <span className="absolute bottom-2 left-2 bg-zinc-900/80 text-xs px-2 py-1 rounded">Procesando…</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
