'use client';
import { useEffect, useRef, useState } from 'react';

export default function Uploader() {
  const [eventId, setEventId] = useState('');
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const onPick = () => inputRef.current?.click();

  const handleFiles = async (files: FileList | null) => {
    if (!files || !eventId) return;
    setBusy(true);
    for (const file of Array.from(files)) {
      const ext = file.type.split('/')[1] || 'jpg';
      const res = await fetch('/api/presign', { method: 'POST', body: JSON.stringify({ eventId, ext }) });
      const { url, publicUrl } = await res.json();
      await fetch(url, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
      await fetch('/api/photos', { method: 'POST', body: JSON.stringify({ eventId, originalUrl: publicUrl }) });
    }
    setBusy(false);
    alert('¡Subidas!');
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const eid = params.get('event');
      if (eid) setEventId(eid);
    }
  }, []);

  return (
    <div className="min-h-screen bg-black text-white p-6 flex flex-col gap-4">
      <h1 className="text-2xl font-bold">Flare Uploader</h1>
      <label className="text-sm opacity-80">Event ID</label>
      <input value={eventId} onChange={(e)=>setEventId(e.target.value)} className="bg-zinc-900 p-3 rounded" placeholder="uuid del evento"/>
      <input ref={inputRef} type="file" accept="image/*" capture="environment" multiple className="hidden"
        onChange={(e)=>handleFiles(e.target.files)} />
      <button onClick={onPick} disabled={!eventId || busy}
        className="bg-orange-500 hover:bg-orange-600 disabled:opacity-50 rounded px-4 py-3 font-semibold">
        {busy ? 'Subiendo...' : 'Tomar/Subir fotos'}
      </button>
      <p className="text-sm opacity-70">Tip: instala esta página como app (PWA) y usa la cámara del móvil.</p>
    </div>
  );
}
