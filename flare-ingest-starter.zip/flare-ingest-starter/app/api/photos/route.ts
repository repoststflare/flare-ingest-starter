import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase-server';

export async function POST(req: Request) {
  const body = await req.json();
  const { eventId, originalUrl, takenAt, athleteTag, teamTag, meta } = body;
  if (!eventId || !originalUrl) {
    return NextResponse.json({ error: 'eventId & originalUrl required' }, { status: 400 });
  }
  const sb = supabaseServer();
  const { data, error } = await sb.from('photos').insert({
    event_id: eventId,
    original_url: originalUrl,
    taken_at: takenAt ? new Date(takenAt).toISOString() : new Date().toISOString(),
    athlete_tag: athleteTag || null,
    team_tag: teamTag || null,
    meta: meta || {},
    status: 'uploaded',
  }).select('*').single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, photo: data });
}

export async function PUT(req: Request) {
  const body = await req.json();
  const { photoId, editedUrl } = body;
  if (!photoId || !editedUrl) {
    return NextResponse.json({ error: 'photoId & editedUrl required' }, { status: 400 });
  }
  const sb = supabaseServer();
  const { data, error } = await sb
    .from('photos')
    .update({ edited_url: editedUrl, status: 'processed', processed_at: new Date().toISOString() })
    .eq('id', photoId)
    .select('*')
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, photo: data });
}
