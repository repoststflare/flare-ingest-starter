import { NextResponse } from 'next/server';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { randomUUID } from 'crypto';

const client = new S3Client({
  region: process.env.S3_REGION,
  endpoint: process.env.S3_ENDPOINT,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID!,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
  },
});

export async function POST(req: Request) {
  const { eventId, ext = 'jpg' } = await req.json();
  if (!eventId) return NextResponse.json({ error: 'eventId required' }, { status: 400 });
  const key = `events/${eventId}/${randomUUID()}.${ext}`;

  const command = new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    ContentType: `image/${ext}`,
  });

  const url = await getSignedUrl(client, command, {
    expiresIn: Number(process.env.PRESIGN_EXPIRES_SECONDS || 3600),
  });

  return NextResponse.json({ key, url, publicUrl: `${process.env.S3_PUBLIC_BASE}/${key}` });
}
