export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold">Flare Ingest v0</h1>
      <ul className="mt-6 list-disc pl-6 space-y-2">
        <li><a className="text-orange-400 underline" href="/uploader">Uploader (cámara)</a></li>
        <li><a className="text-orange-400 underline" href="/gallery/00000000-0000-0000-0000-000000000000">Galería demo (cambia el eventId)</a></li>
      </ul>
    </main>
  );
}
